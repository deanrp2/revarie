<p align="center">
<img src="docs/logo/logo.png" height="120px">
</p>

# Overview
Revarie is intended to be a spatial statistical analysis toolset which is targeted for computational physics applications.
Its primary focus is on variography of cartesian fields. Currently, it supports computation and fitting of isotropic variograms along with other tools to support random field generation.

# Variogram Calculation

# Field Generation
